from django.urls import path
from . import api_views

urlpatterns = [
    path('students/', api_views.StudentListAPI.as_view(), name='student_list_api'),
    path('students/<int:pk>/', api_views.StudentDetailAPI.as_view(), name='student_detail_api'),
]
